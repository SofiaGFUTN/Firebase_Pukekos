// js/users/signup.js
// create local database firestore variable
var db = firebase.apps[0].firestore();
var auth = firebase.apps[0].auth();

// create local from webpage inputs
const txtNombre = document.querySelector('#txtNombre');
const txtEmail = document.querySelector('#txtEmail');
const txtContra = document.querySelector('#txtContra');

// create local insert button
const btnInsUser = document.querySelector('#btnInsUser');

btnInsUser.addEventListener('click', function () {
    if (!txtNombre.value || !txtEmail.value || !txtContra.value) {
        alert('Complete todos los campos.');
        return;
    }
	auth.createUserWithEmailAndPassword(txtEmail.value, txtContra.value)
		.then((userCredential) => {
			const user = userCredential.user;
            const now = firebase.firestore.FieldValue.serverTimestamp();
			db.collection("datosUsuarios").add({
				"idemp": user.uid,
				"usuario": txtNombre.value,
				"email": user.email,
                "createdAt": now,     // fecha de creación
                "ultAcceso": now      // iniciar ultAcceso con la misma marca de tiempo
			}).then(function (docRef) {
				alert("Usuario agregado satisfactoriamente");
				limpiar();
			}).catch(function (FirebaseError) {
				alert("Error al registrar datos del usuario." + FirebaseError);
			});
		})
		.catch((error) => {
			alert("Error al agregar el nuevo usuario: " + error.message);
		});
});

// al autenticar y actualizar ultAcceso
const now = firebase.firestore.FieldValue.serverTimestamp();
db.collection("datosUsuarios").where('idemp', '==', user.uid).get()
    .then(function (docRef) {
        docRef.forEach(function (doc){
            doc.ref.update({ultAcceso: now}).then(function (){
                document.location.href = 'index.html';
            });
        });
    })

function limpiar(){
	txtNombre.value = '';
	txtEmail.value = '';
	txtContra.value = '';
	txtNombre.focus();
}
