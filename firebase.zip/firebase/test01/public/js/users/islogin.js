// js/users/islogin.js
var auth = firebase.apps[0].auth();

function validar() {
    auth.onAuthStateChanged((user) => {
        if (user) {
            // user logged in
            startInactivityTimer();
        } else {
            document.location.href = 'login.html';
        }
    });
    return -1;
}

// close current session
function salir(){
    auth.signOut().then(() => {
        document.location.href ='login.html';
    }).catch((error)=>{
       alert('Error al cerrar la sesión: ' + error.message);
    });
}

/* Inactivity (3 minutes)  */
let inactivityTimeout = null;
const INACTIVITY_MS = 3 * 60 * 1000;

function resetTimer(){
    if(inactivityTimeout) clearTimeout(inactivityTimeout);
    inactivityTimeout = setTimeout(()=> {
        // for security, sign out the user
        auth.signOut().then(()=>{
            alert('Sesión cerrada por inactividad (3 minutos).');
            document.location.href = 'login.html';
        }).catch(err=>{
            console.error('Error al cerrar sesión por inactividad', err);
            document.location.href = 'login.html';
        });
    }, INACTIVITY_MS);
}

function startInactivityTimer(){
    const events = ['mousemove','mousedown','keypress','touchstart','scroll','click'];
    events.forEach(ev => document.addEventListener(ev, resetTimer, true));
    resetTimer(); 
}
