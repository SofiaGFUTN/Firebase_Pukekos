// js/zodiac/addsigno.js
var db = firebase.apps[0].firestore();
var container = firebase.apps[0].storage().ref();

const txtPosic = document.querySelector('#txtPosic');
const txtSigno = document.querySelector('#txtSigno');
const txtRango = document.querySelector('#txtRango');
const txtElemento = document.querySelector('#txtElemento');
const txtAstro = document.querySelector('#txtAstro');
const txtPiedra = document.querySelector('#txtPiedra');
const txtArchi = document.querySelector('#txtArchi');
const btnLoad  = document.querySelector('#btnLoad');

btnLoad.addEventListener('click', function(){
    const archivo = txtArchi.files[0];
    if(!archivo){
        alert('Debe seleccionar una imagen');
        return;
    }
    if(!txtPosic.value || !txtSigno.value || !txtRango.value || !txtElemento.value){
        alert('Complete los campos obligatorios (Posición, Signo, Rango, Elemento).');
        return;
    }
    const nomarch = Date.now() + '_' + archivo.name;
    const metadata = { contentType : archivo.type };
    const subir = container.child('zodiaco/'+nomarch).put(archivo, metadata);
    subir
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then( url =>{
            db.collection("datosZodiaco").add({
                "posic" : parseInt(txtPosic.value),
                "signo" : txtSigno.value,
                "rango" : txtRango.value,
                "url"   : url,
                "elemento": txtElemento.value,
                "astro": txtAstro.value || '',
                "piedra": txtPiedra.value || ''
            }).then(function(docRef) {
                alert("ID del registro: " + docRef.id);
                limpiar();
            }).catch(function(FirebaseError) {
                alert("Error al subir la imagen / datos: " + FirebaseError);
            });
        }).catch(err => {
            alert('Error al obtener URL: ' + err);
        });
});

function limpiar(){
    txtPosic.value = ''
    txtSigno.value = '';
    txtRango.value = '';
    txtElemento.value = '';
    txtAstro.value = '';
    txtPiedra.value = '';
    txtArchi.value = '';
    txtPosic.focus();
}