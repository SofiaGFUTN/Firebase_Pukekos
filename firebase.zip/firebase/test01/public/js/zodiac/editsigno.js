// js/zodiac/editsigno.js
var db = firebase.apps[0].firestore();
var storageRef = firebase.apps[0].storage().ref();

const txtPosic = document.querySelector('#txtPosic');
const txtSigno = document.querySelector('#txtSigno');
const txtRango = document.querySelector('#txtRango');
const txtElemento = document.querySelector('#txtElemento');
const txtAstro = document.querySelector('#txtAstro');
const txtPiedra = document.querySelector('#txtPiedra');
const txtArchi = document.querySelector('#txtArchi');
const btnUpdate = document.querySelector('#btnUpdate');

// helper to get query param
function getQueryParam(name){
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

const docId = getQueryParam('id');
if(!docId){
    alert('No se indicó el id del signo a editar.');
}

// load current data
db.collection('datosZodiaco').doc(docId).get().then(doc=>{
    if(!doc.exists) {
        alert('Documento no encontrado');
        return;
    }
    const d = doc.data();
    txtPosic.value = d.posic || '';
    txtSigno.value = d.signo || '';
    txtRango.value = d.rango || '';
    txtElemento.value = d.elemento || '';
    txtAstro.value = d.astro || '';
    txtPiedra.value = d.piedra || '';
}).catch(err => {
    alert('Error cargando documento: ' + err);
});

// actualizar
btnUpdate.addEventListener('click', function(){
    if(!txtPosic.value || !txtSigno.value || !txtElemento.value){
        alert('Complete los campos obligatorios.');
        return;
    }
    const archivo = txtArchi.files[0];
    if(archivo){
        const nomarch = Date.now() + '_' + archivo.name;
        storageRef.child('zodiaco/' + nomarch).put(archivo)
            .then(snapshot => snapshot.ref.getDownloadURL())
            .then(url => {
                return db.collection('datosZodiaco').doc(docId).update({
                    posic: parseInt(txtPosic.value),
                    signo: txtSigno.value,
                    rango: txtRango.value,
                    elemento: txtElemento.value,
                    astro: txtAstro.value || '',
                    piedra: txtPiedra.value || '',
                    url: url
                });
            }).then(()=>{
                alert('Registro actualizado');
                location.href = 'lista.html';
            }).catch(err=>{
                alert('Error al subir imagen / actualizar: ' + err);
            });
    } else {
        db.collection('datosZodiaco').doc(docId).update({
            posic: parseInt(txtPosic.value),
            signo: txtSigno.value,
            rango: txtRango.value,
            elemento: txtElemento.value,
            astro: txtAstro.value || '',
            piedra: txtPiedra.value || ''
        }).then(()=>{
            alert('Registro actualizado');
            location.href = 'lista.html';
        }).catch(err=>{
            alert('Error al actualizar: ' + err);
        });
    }
});
