// js/zodiac/lstzodiaco.js
var db = firebase.apps[0].firestore();

const tabla = document.querySelector('#tabla');

function crearCard(doc){
    const data = doc.data();
    // build HTML
    let salida = '';
    salida += '<div class="divAnuncio m-3" style="cursor:pointer" onclick="location.href=\'edit.html?id='+doc.id+'\'">';
    salida += '<div class="imgBlock"><img src="' + data.url +'" width="100%" alt="'+data.signo+'"/></div>';
    salida += '<div><strong>' + data.signo + '</strong><br/>' + data.rango + '</div>';
    salida += '<div>Elemento: ' + (data.elemento || '') + '</div>';
    salida += '<div>Astro: ' + (data.astro || '') + '</div>';
    salida += '<div>Piedra: ' + (data.piedra || '') + '</div>';
    salida += '</div>';
    return salida;
}

db.collection("datosZodiaco").orderBy('posic', 'asc').get().then(function(query){
    tabla.innerHTML="";
    var salida = "";
    query.forEach(function(doc){
        salida += crearCard(doc);
    })
    tabla.innerHTML = salida;
}).catch(err => {
    tabla.innerHTML = '<p>Error cargando datos: '+err+'</p>';
});
